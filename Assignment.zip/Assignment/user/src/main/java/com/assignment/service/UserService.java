package com.assignment.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.assignment.model.Login;
import com.assignment.model.User;

import com.assignment.repository.UserRespository;


@Service
public class UserService {

	@Autowired
	UserRespository repo;

		
	  public UserService() 
	  {
	  
	  }
	  
	  
	  public UserService(UserRespository repo)
	  { 
		  super(); 
		  this.repo = repo; 
	  }
	  
	  
	  public void saveMyUser(User user)
	  {
		  repo.save(user);
	  }
	  
	 
	
	
	
	  public String loginUser(Login login) 
	  { 
		
		  User user = repo.findByUsername(login.getUsername()); 
		 
		  if(user == null) 
		  { 
			  return "User does not exist.";
		  } 
		  if(user.getUsername().equals(login.getUsername()) && (user.getPassword().equals(login.getPassword()))) 
		  { 
			  return "Login success" ; 
		  } 
		  return "Password mismatch" ;
		 
	  }
	 
	


	
	public Iterable<User> showAllUsers()
	{
		return repo.findAll();
	}
	
	
	public Iterable<User> deleteUserByUsername(String username)
	{
		repo.deleteByUsername(username);
		return repo.findAll();
		
	}
	
	
	public User findByUsername(String username)
	{
		return repo.findByUsername(username);
	}
	
	public User saveUserdetails(User use)
    {
        return repo.save(use);
    }

}
