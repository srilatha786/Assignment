package com.assignment.controller;



import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;



import com.assignment.model.Login;
import com.assignment.model.User;
import com.assignment.service.UserService;



@org.springframework.web.bind.annotation.RestController
public class RestController {
	
	@Autowired
	private UserService service;
	
	
 
	/*** register a user***/
	 @PostMapping("/saveuser")
	 @Transactional
	  public String registerUser(@RequestBody User user)
	  {
		service.saveMyUser(user);
		return "Hello"  +user.getFirstname()+   "your registration is successfull";
	  }
	 
	
	 /***show all user details***/
	 @GetMapping("/allusers")
	 public Iterable<User> showAllUsers()
	 {
		 return service.showAllUsers();
		 
	 }
	 
		
	 	
		  @PostMapping("/login") 
		  public String loginUser(@RequestBody Login login)
		  {
		  return service.loginUser(login);
		  
		  
		  }
		 
		
	 	 
	 /***delete a user***/
	 @GetMapping("/delete/{username}")
	 @Transactional
	 public Iterable<User> deleteUser(@PathVariable String username)
	 {
		 return service.deleteUserByUsername(username);
	 }
	 
	 
	   /***search a user***/
	 @GetMapping("search/{username}")
	 public User searchUser(@PathVariable String username)
	 {
		 return service.findByUsername(username);
	 }
	 
	  
	 @PutMapping("/update")
	    @Transactional
	    public String updateUserDetails(@RequestBody User use)
	        {
	        service.saveUserdetails(use);
	        return "Hello" +use.getUsername()+" your details are added successfully";
	           }
}
