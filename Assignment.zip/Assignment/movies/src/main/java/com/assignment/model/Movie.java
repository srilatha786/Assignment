package com.assignment.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "movietable")
public class Movie 
{
	
	@Id
	private int movieId;
	private String moviename;
	private String movietype;
	private String movielanguage;
	private String moviedirector;


public Movie()
{
	
}


public Movie(int movieId, String moviename, String movietype, String movielanguage, String moviedirector) {
	super();
	this.movieId = movieId;
	this.moviename = moviename;
	this.movietype = movietype;
	this.movielanguage = movielanguage;
	this.moviedirector = moviedirector;
}


public int getmovieId() {
	return movieId;
}


public void setmovieId(int movieId) {
	this.movieId = movieId;
}


public String getMoviename() {
	return moviename;
}


public void setMoviename(String moviename) {
	this.moviename = moviename;
}


public String getMovietype() {
	return movietype;
}


public void setMovietype(String movietype) {
	this.movietype = movietype;
}


public String getMovielanguage() {
	return movielanguage;
}


public void setMovielanguage(String movielanguage) {
	this.movielanguage = movielanguage;
}


public String getMoviedirector() {
	return moviedirector;
}


public void setMoviedirector(String moviedirector) {
	this.moviedirector = moviedirector;
}










}
