package com.assignment.controller;





import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.assignment.model.Movie;

import com.assignment.service.MovieService;

@org.springframework.web.bind.annotation.RestController
public class RestController {

	

	@Autowired
	private MovieService service;
	
	
	
	 @PostMapping("/addmovie")
	 @Transactional
	  public String registerMovie(@RequestBody Movie movie)
	  {
		service.addMovie(movie);
		return "movie is added successfully";
	  }
	 

	 @GetMapping("/allmovies")
	 public Iterable<Movie> showAllMovies()
	 {
		 return service.showAllMovies();
		 
	 }
	 
	 @GetMapping("/delete/{moviename}")
	 @Transactional
	 public Iterable<Movie> deleteMovie(@PathVariable String moviename)
	 {
		 return service.deleteMovieByMoviename(moviename);
	 }
	 
	 
	 @GetMapping("search/{moviename}")
	 public Movie searchMovie(@PathVariable String moviename)
	 {
		 return service.findByMoviename(moviename);
	 }
}
