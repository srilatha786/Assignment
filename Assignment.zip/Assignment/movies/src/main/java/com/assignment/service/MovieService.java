package com.assignment.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.assignment.model.Movie;
import com.assignment.repository.MovieRepository;



@Service
public class MovieService {

	@Autowired
	MovieRepository repo;
	
	
	  public MovieService() 
	  {
	  
	  }
	  
	  
	  public MovieService(MovieRepository repo)
	  { 
		  super(); 
		  this.repo = repo; 
	  }
	  
	  
	  public void addMovie(Movie movie)
	  {
		  repo.save(movie);
	  }
	  
	  public Iterable<Movie> showAllMovies()
		{
			return repo.findAll();
		}
		
		
		public Iterable<Movie> deleteMovieByMoviename(String moviename)
		{
			repo. deleteByMoviename(moviename);
			return repo.findAll();
			
		}
		
		
		public Movie findByMoviename(String moviename)
		{
			return repo.findByMoviename(moviename);
		}
	
}

