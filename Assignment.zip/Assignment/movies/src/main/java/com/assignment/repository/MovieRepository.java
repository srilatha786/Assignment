package com.assignment.repository;

import com.assignment.model.Movie;

import org.springframework.data.repository.CrudRepository;





public interface MovieRepository extends CrudRepository<Movie, Integer>{

	
public Iterable<Movie> deleteByMoviename(String moviename);
	
	public Movie findByMoviename(String moviename);
}

