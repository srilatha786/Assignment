package com.assignment.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;



	@Entity
	@Table(name = "theatretable")
	public class Theatre 
	{
		
		@Id
		private int theatreId;
		private String theatrename;
		private String theatrelocation;
		private int theatreprice;
		private String theatrecapacity;
	
	
	public Theatre()
	{
		
	}


	public Theatre(int theatreId, String theatrename, String theatrelocation, int theatreprice, String theatrecapacity) {
		super();
		this.theatreId = theatreId;
		this.theatrename = theatrename;
		this.theatrelocation = theatrelocation;
		this.theatreprice = theatreprice;
		this.theatrecapacity = theatrecapacity;
	}


	public int gettheatreId() {
		return theatreId;
	}


	public void settheatreId(int theatreId) {
		this.theatreId = theatreId;
	}


	public String getTheatrename() {
		return theatrename;
	}


	public void setTheatrename(String theatrename) {
		this.theatrename = theatrename;
	}


	public String getTheatrelocation() {
		return theatrelocation;
	}


	public void setTheatrelocation(String theatrelocation) {
		this.theatrelocation = theatrelocation;
	}


	public int getTheatreprice() {
		return theatreprice;
	}


	public void setTheatreprice(int theatreprice) {
		this.theatreprice = theatreprice;
	}


	public String getTheatrecapacity() {
		return theatrecapacity;
	}


	public void setTheatrecapacity(String theatrecapacity) {
		this.theatrecapacity = theatrecapacity;
	}




	}
	
	

	

