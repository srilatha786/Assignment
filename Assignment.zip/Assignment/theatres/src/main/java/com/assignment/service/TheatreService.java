package com.assignment.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.assignment.model.Theatre;

import com.assignment.repository.TheatreRepository;

@Service
public class TheatreService {

	@Autowired
	TheatreRepository repo;
	
	
	  public TheatreService() 
	  {
	  
	  }
	  
	  
	  public TheatreService(TheatreRepository repo)
	  { 
		  super(); 
		  this.repo = repo; 
	  }
	  
	  
	  public void addTheatre(Theatre theatre)
	  {
		  repo.save(theatre);
	  }
	  
	  public Iterable<Theatre> showAllTheatres()
		{
			return repo.findAll();
		}
		
		
		public Iterable<Theatre> deleteTheatreByTheatrename(String theatrename)
		{
			repo. deleteByTheatrename(theatrename);
			return repo.findAll();
			
		}
		
		
		public Theatre findByTheatrename(String theatrename)
		{
			return repo.findByTheatrename(theatrename);
		}
	
}
