package com.assignment.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.assignment.model.Theatre;
import com.assignment.service.TheatreService;


@org.springframework.web.bind.annotation.RestController 
public class RestController
{

	@Autowired
	private TheatreService service;
	
	 @PostMapping("/addtheatre")
	 @Transactional
	  public String registerTheatre(@RequestBody Theatre theatre)
	  {
		service.addTheatre(theatre);
		return "theatre added successfully";
	  }
	 
	 @GetMapping("/alltheatres")
	 public Iterable<Theatre> showAllTheatres()
	 {
		 return service.showAllTheatres();
		 
	 }
	 
	
	 @GetMapping("/delete/{theatrename}")
	 @Transactional
	 public Iterable<Theatre> deleteTheatre(@PathVariable String theatrename)
	 {
		 return service.deleteTheatreByTheatrename(theatrename);
	 }
	 
	 
	 
	 @GetMapping("search/{theatrename}")
	 public Theatre searchTheatre(@PathVariable String theatrename)
	 {
		 return service.findByTheatrename(theatrename);
	 }

}
