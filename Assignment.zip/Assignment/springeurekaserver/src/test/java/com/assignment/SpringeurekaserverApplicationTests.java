package com.assignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringeurekaserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
