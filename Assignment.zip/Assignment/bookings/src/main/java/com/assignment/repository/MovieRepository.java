package com.assignment.repository;



import org.springframework.data.repository.CrudRepository;

import com.assignment.model.Movie;






public interface MovieRepository extends CrudRepository<Movie, Integer>{

	
public Iterable<Movie> deleteByMoviename(String moviename);
	
	public Movie findByMoviename(String moviename);
}

