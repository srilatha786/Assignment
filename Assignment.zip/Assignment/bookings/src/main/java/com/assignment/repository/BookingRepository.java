package com.assignment.repository;

import java.util.ArrayList;

import org.springframework.data.repository.CrudRepository;

import com.assignment.model.Booking;
import com.assignment.model.Show;

import antlr.collections.List;



public interface BookingRepository extends CrudRepository<Booking, Integer>{

	/* ArrayList<Booking> findShowByMovie(Integer movieId); */
	 
}
