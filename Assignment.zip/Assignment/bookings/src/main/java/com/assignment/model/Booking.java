package com.assignment.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;




@Entity
public class Booking {
    
    @Id
    private int bookingId;
    @OneToOne
    @JoinColumn(name="userid",referencedColumnName="userId")
    private User userid;
    @OneToOne
    @JoinColumn(name="showid")
    private Show showid;
    
    private int seatsbooked;
    private int amount;
    private String bookingstatus;
    
    public  Booking() {
    }
    
    
	public Booking(int bookingId, User userid, Show showid, int seatsbooked, int amount, String bookingstatus) {
		super();
		this.bookingId = bookingId;
		this.userid = userid;
		this.showid = showid;
		this.seatsbooked = seatsbooked;
		this.amount = amount;
		this.bookingstatus = bookingstatus;
	}


	public int getBookingId() {
		return bookingId;
	}


	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}


	public User getUserid() {
		return userid;
	}


	public void setUserid(com.assignment.model.User user) {
		this.userid = user;
	}


	public Show getShowid() {
		return showid;
	}


	public void setShowid(Show showid) {
		this.showid = showid;
	}


	public int getSeatsbooked() {
		return seatsbooked;
	}


	public void setSeatsbooked(int seatsbooked) {
		this.seatsbooked = seatsbooked;
	}


	public int getAmount() {
		return amount;
	}


	public void setAmount(int amount) {
		this.amount = amount;
	}


	public String getBookingstatus() {
		return bookingstatus;
	}


	public void setBookingstatus(String bookingstatus) {
		this.bookingstatus = bookingstatus;
	}
	
	
    

	
	

	
}
