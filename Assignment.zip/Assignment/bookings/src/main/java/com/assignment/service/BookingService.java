package com.assignment.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.assignment.model.AddShow;
import com.assignment.model.Booking;
import com.assignment.model.Movie;
import com.assignment.model.Show;
import com.assignment.model.Theatre;
import com.assignment.model.User;
import com.assignment.repository.BookingRepository;
import com.assignment.repository.MovieRepository;
import com.assignment.repository.ShowRepository;
import com.assignment.repository.TheatreRepository;
import com.assignment.repository.UserRespository;

@Service
public class BookingService {

 

    @Autowired
    MovieRepository mrepo;
    @Autowired
    TheatreRepository trepo;
    @Autowired
    ShowRepository srepo;
    @Autowired
    UserRespository urepo;
    @Autowired
    BookingRepository brepo;

 

    public String Addshow(Show show) {

         String message = null;
        System.out.println("before movie--------------");
        Movie movie = new Movie();
		/* System.out.println(show.get); */

 

        movie = mrepo.findByMoviename(show.getMovieid().getMoviename());
        System.out.println(movie.getId());
        mrepo.save(movie);
        System.out.println("before theatre--------------");
        Theatre theatre = new Theatre();
        theatre = trepo.findByTheatrename(show.getTheatreid().getTheatrename());

 

        if (movie != null && theatre != null) {
            System.out.println("inside if--------------");
            Show newshow = new Show();
            System.out.println(movie.getId());
            System.out.println(movie.getMoviename());
            System.out.println(movie.getMovielanguage());
            System.out.println(movie.getMovietype());
            newshow.setMovieid(movie);

 
            newshow.setShowdate(show.getShowdate());
            newshow.setShowtime(show.getShowtime());
            newshow.setSeatsavailable(show.getSeatsavailable());
            newshow.setRate(show.getRate());

 

            System.out.println("before showtime=-==============");
            newshow.setMovieid(movie);
            System.out.println("aftr movie");
            System.out.println(newshow.getMovieid().getMovietype());
            newshow.setTheatreid(theatre);

 

            

            srepo.save(newshow);
            message = "show added successfully!!";
        } else {

 

            message = "movie and theatre are not present in list!!";
        }
        return message;

 

    }
    
   
     public ResponseEntity<Booking> AddBooking(Booking booking)
     { 
         String message = null;
			/* Booking booking1 = new Booking(); */
   /*  booking.setSeatsbooked(bookticket.getSeatsBooked());*/
     User user =urepo.findByUsername(booking.getUserid().getUsername());
     System.out.println("after user");
     int amount;
     Iterable<Show> shows =srepo.findAll();
     System.out.println("after show");
      try
      {
      for (Show show : shows) 
      { 
    	  System.out.println("Hai");
          System.out.println(booking.getShowid().getMovieid().getMoviename());
      System.out.println(show.getMovieid().getMoviename()); 
      
      if(show.getMovieid().getMoviename().equalsIgnoreCase(booking.getShowid().getMovieid().getMoviename()) && show.getTheatreid().getTheatrename().equalsIgnoreCase(booking.getShowid().getTheatreid().getTheatrename()))
      { 
          System.out.println("inside first if");
          
          
          if(show.getShowdate().equals(booking.getShowid().getShowdate()) && show.getShowtime().equals(booking.getShowid().getShowtime()))
          {
              if(show.getSeatsavailable() > booking.getSeatsbooked()) 
              {
           
                  booking.setUserid(user);
                  
                          booking.setSeatsbooked(booking.getSeatsbooked());
                          amount = show.getRate();
                          booking.getSeatsbooked(); 
                          booking.setAmount(amount);
                          booking.setBookingstatus("booking confirmed"); 
                          brepo.save(booking);
                          message = "booking confirmed!!";
                          show.setSeatsavailable(show.getSeatsavailable() - booking.getSeatsbooked());
							/* show.setTicketprice(booking.getAmount()); */
                          
      
      } 
     /*     else
      { 
          message = "seats not available!!"; */
          
			/*
			 * } else { message="show is not available for the time"; }
			 */
      }
      
      /*else {
          message = "movie and threatre is not available!!"; 
      } */
      }
      
      }
      if(message.equals("booking confirmed!!")) {
          return ResponseEntity.ok(booking);
      }
      else {
          return ResponseEntity.badRequest().build();
      }
      }catch(Exception e) {
         return ResponseEntity.badRequest().build();
         
      }
     }
    

 


    public Iterable<Show> getallshows() {

 

        Iterable<Show> shows = srepo.findAll();
		/* List<Show> showlist = new ArrayList<>(); */

 

		/* for (Show show : shows) { */
        	
       
			/* GetShow getshow = new GetShow(); */
			/*
			 * show.setMoviename(show.getMovieId().getMoviename();
			 * show.setRate(show.getTicketPrice());
			 * show.setSeatsavailable(show.getSeatsAvailable());
			 * show.setShowdate(show.getShowDate()); show.setShowtime(show.getShowTime());
			 * show.setTheatrename(show.getTheatreId().getTheatrename());
			 * show.setShowid(show.getShowId());
			 */

 

		/* showlist.add(getshow); */
        
        return shows;
    }
    
        public List<Booking> getallbookings() {
        List<Booking> list = new ArrayList<>();

 

        Iterable<Booking> booking = brepo.findAll();
        for (Booking book : booking) {
        	Booking bookdetails = new Booking();
            bookdetails.setAmount(book.getAmount());
            bookdetails.setBookingId(book.getBookingId());
			/* bookdetails.setMoviename(book.getShowid().getMovieId().getMoviename()); */
            bookdetails.setSeatsbooked(book.getSeatsbooked());
			/*
			 * bookdetails.setShowdate(book.getShowid().getShowDate());
			 * bookdetails.setShowtime(book.getShowid().getShowTime());
			 * bookdetails.setTheatrename(book.getShowid().getTheatreId().getTheatrename());
			 */
            bookdetails.setBookingstatus(book.getBookingstatus());
            bookdetails.setShowid(book.getShowid());
            bookdetails.setUserid(book.getUserid());
            list.add(bookdetails);
        }
        return list;
    }
        
        
        public String deleteBooking(int bookingid) {
            String message = null;
            Optional<Booking> booking = brepo.findById(bookingid);

     

            if (booking.isPresent()) {
                if (!(booking.get().getBookingstatus().equalsIgnoreCase("cancelled"))) {
                    Show show = booking.get().getShowid();
                    int seatsavailable = show.getSeatsavailable();
                    show.setSeatsavailable(booking.get().getSeatsbooked() + show.getSeatsavailable());
                    booking.get().setBookingstatus("cancelled");
                    message = "booking cancelled successfully";
                    brepo.save(booking.get());
                }
                message = "already cancelled";
            }

     

            else
                message = "booking id is not exist!!";

     

            return message;

     

        }
        
        
        public ResponseEntity<List<Booking>> getreport(String fromdate,String enddate) {
            Iterable<Booking> bookings=brepo.findAll();
            try {
                  /*
                   * Date strtdate1=new SimpleDateFormat("DD-MMM-YYYY").parse(fromdate);
                   *
                   * Date enddate2=new SimpleDateFormat("DD-MMM-YYYY").parse(enddate);
                   */
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
                   LocalDate strtdate1 = LocalDate.parse(fromdate, formatter);
                   DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
                   LocalDate enddate1 = LocalDate.parse(enddate, formatter);
                List<Booking> filteredlist=new ArrayList();
                  /*
                   * DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
                   * LocalDate date1 = LocalDate.parse("27-Sep-2015", formatter);
                   * System.out.println("date string : 27-Sep-2015, " + "localdate : " + date1);
                   */
             
                for(Booking booking:bookings) {
                    DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
                       LocalDate date1 = LocalDate.parse(booking.getShowid().getShowdate(), formatter2);
                      /*
                       * Date showdate=new
                       * SimpleDateFormat("DD-MMM-YYYY").parse(booking.getShowid().getShowdate());
                       * LocalDate date =
                       * showdate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                       */
                           System.out.println(date1);
                    System.out.println("-----------------");
                    if( date1.isAfter(strtdate1)  && date1.isBefore(enddate1)) {
                        System.out.println("-----------inside if-----------");
                       
                        filteredlist.add(booking);
                       
                    }
                   
                }
                return ResponseEntity.ok(filteredlist);
               
          
            }catch(Exception e) {
                return ResponseEntity.badRequest().build();
            }
            }

     

     

        
          public String deleteshowbyid(int id) {
           String message=null;
         
         if( srepo.existsById(id)) {
             srepo.deleteById(id);
             message="show deleted succesfully";
         }
         else {
             message="id not present";
         }
          
             return message; 
          
          }
        
}
    
    



