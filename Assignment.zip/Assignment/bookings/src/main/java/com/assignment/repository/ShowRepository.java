package com.assignment.repository;

import org.springframework.data.repository.CrudRepository;


import com.assignment.model.Show;

public interface ShowRepository extends CrudRepository<Show, Integer>{
	
	/* public Show findByShowName(String showname) */;
}



