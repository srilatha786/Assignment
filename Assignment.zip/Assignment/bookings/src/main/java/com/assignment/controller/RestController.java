package com.assignment.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestBody;



import com.assignment.model.Booking;
import com.assignment.model.Show;
import com.assignment.service.BookingService;


@org.springframework.web.bind.annotation.RestController
public class RestController
{

@Autowired
BookingService bserv;



@PostMapping("/addshow")
@Transactional
public String AddShow(@RequestBody Show show) {



    return bserv.Addshow(show);



}

 @PostMapping("/addbooking")
 @Transactional
 public ResponseEntity<Booking> AddBooking(@RequestBody Booking booking) {
  
       return bserv.AddBooking(booking);
  
 }
 

 @GetMapping("/allbookings")
 
  @Transactional public List<Booking> getallbookings()
 { return bserv.getallbookings();
  
  }




@DeleteMapping("/deletebooking/{bookingid}")
 
  @Transactional public String deleteBooking(@PathVariable int bookingid) {
  
  return bserv.deleteBooking(bookingid);
  
  }

@GetMapping("/getreport/{fromdate}/{enddate}")
public ResponseEntity<List<Booking>> getreport(@PathVariable String fromdate,@PathVariable String enddate) {
   
   return bserv.getreport(fromdate, enddate);
   
   
}


  @GetMapping("/allshows")
 
  @Transactional 
  public Iterable<Show> getallshows(){
  
  return bserv.getallshows();
  
 
  }




 @DeleteMapping("/deleteshow/{showid}")
 public String deleteshowbyid(@PathVariable int showid) {
     return bserv.deleteshowbyid(showid);
  
        /* return bserv.deleteshowbyid(showid); */
  
  }
 }

