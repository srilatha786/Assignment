package com.assignment.model;

/*import java.sql.Date;*/
import java.sql.Time;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.sun.istack.NotNull;

@Entity
@Table(name = "showtable")
public class Show {

 

    @Id
    @Column(name = "id")                
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private int  showId;
    
    @OneToOne
    @JoinColumn(name="movieid",referencedColumnName="movieId")
    private Movie movieid;
       
    
    @OneToOne
    @JoinColumn(name="theatreid",referencedColumnName="theatreId")
    private Theatre theatreid;
    
    private int rate;
    
   
    public int getRate() {
		return rate;
	}

	
	/* private int ticketprice; */

 
    private String showdate;

 
    private String showtime;

 
    private int seatsavailable;
    
    public Show()
    {
    	
    }

	public Show(Movie movieid, Theatre theatreid, int rate, int ticketprice, String showdate, String showtime,
			int seatsavailable) {
		super();
		this.movieid = movieid;
		this.theatreid = theatreid;
		this.rate = rate;
		/* this.ticketprice = ticketprice; */
		this.showdate = showdate;
		this.showtime = showtime;
		this.seatsavailable = seatsavailable;
	}

	public int getShowId() {
		return showId;
	}

	public void  setShowId(Integer showId) {
		this.showId = showId;
	}

	public Movie getMovieid() {
		return movieid;
	}

	public void setMovieid(Movie movieid) {
		this.movieid = movieid;
	}

	public Theatre getTheatreid() {
		return theatreid;
	}

	public void setTheatreid(Theatre theatreid) {
		this.theatreid = theatreid;
	}

	
	/*
	 * public int getTicketprice() { return ticketprice; }
	 */

	/*
	 * public void setTicketprice(int ticketprice) { this.ticketprice = ticketprice;
	 * }
	 */

	public int getSeatsavailable() {
		return seatsavailable;
	}

	public void setSeatsavailable(int seatsavailable) {
		this.seatsavailable = seatsavailable;
	}

	public void setShowId(int showId) {
		this.showId = showId;
	}


	

	public String getShowdate() {
		return showdate;
	}

	public void setShowdate(String showdate) {
		this.showdate = showdate;
	}

	public String getShowtime() {
		return showtime;
	}

	public void setShowtime(String showtime) {
		this.showtime = showtime;
	}

	

	public void setRate(int rate) {
		this.rate = rate;
	}

	
	
 

    

}

 


