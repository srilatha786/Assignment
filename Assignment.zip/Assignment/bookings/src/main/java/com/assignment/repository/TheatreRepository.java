package com.assignment.repository;



import org.springframework.data.repository.CrudRepository;

import com.assignment.model.Theatre;


public interface TheatreRepository extends CrudRepository<Theatre, Integer>{

	
public Iterable<Theatre> deleteByTheatrename(String theatrename);
	
	public Theatre findByTheatrename(String theatrename);
}
